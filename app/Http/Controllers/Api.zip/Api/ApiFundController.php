<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Institute;
use App\Models\User;
use App\Models\FundHead;
use App\Models\Fund;
use App\Models\FundHeld;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class ApiFundController extends Controller
{
    private function validateToken(Request $request)
    {
        $token = $request->header('token');
        if (empty($token) || $token !== env('JWT_SECRET_KEY')) {
            return false;
        }
        return true;
    }

    public function storeInTransaction(Request $request)
    {
        if (!$this->validateToken($request)) {
            return response()->json(['error' => 'Unauthorized: Invalid token'], 401);
        }

        $request->validate([
            'institution_id' => 'required',
            'heads' => 'required|array|min:1',
            'heads.*.name' => 'required|string',
            'heads.*.amount' => 'required|numeric|min:0.01',
            'heads.*.description' => 'nullable|string',
        ]);

        try {
            $institutionId = $request->institution_id;
            
            $institute = Institute::where('hr_id', $institutionId)->first();
            if (!$institute) {
                return response()->json(['error' => 'Institute not found'], 404);
            }

            $user = User::where('inst_id', $institutionId)->first();
            $userId = $user ? $user->id : null;

            $date = Carbon::now()->format('Y-m-d');
            $status = 'Approved';
            $type = 'in';

            DB::transaction(function () use ($request, $institute, $userId, $date, $type, $status) {
                foreach ($request->heads as $headData) {
                    $fundHead = FundHead::where('name', $headData['name'])->first();
                    if (!$fundHead) {
                        throw new \Exception("Fund head '{$headData['name']}' not found.");
                    }

                    $fundHeld = FundHeld::where('fund_head_id', $fundHead->id)
                        ->where('institute_id', $institute->id)
                        ->first();

                    if ($fundHeld) {
                        $newBalance = $fundHeld->balance + $headData['amount'];
                        $fundHeld->update(['balance' => $newBalance]);
                    } else {
                        $newBalance = $headData['amount'];
                        FundHeld::create([
                            'fund_head_id' => $fundHead->id,
                            'institute_id' => $institute->id,
                            'balance'      => $newBalance,
                            'added_by'     => $userId,
                        ]);
                    }

                    Fund::create([
                        'fund_head_id'  => $fundHead->id,
                        'institute_id'  => $institute->id,
                        'amount'        => $headData['amount'],
                        'added_by'      => $userId,
                        'added_date'    => $date,
                        'status'        => $status,
                        'type'          => $type,
                        'description'   => $headData['description'] ?? null,
                        'trans_type'    => 'funds',
                        'approve_by'    => $userId,
                        'approved_date' => now(),
                        'balance'       => $newBalance,
                    ]);
                }
            });

            return response()->json(['message' => 'Fund transaction(s) processed successfully'], 200);

        } catch (\Exception $e) {
            Log::error('API storeInTransaction error: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function transferToRegion(Request $request)
    {
        if (!$this->validateToken($request)) {
            return response()->json(['error' => 'Unauthorized: Invalid token'], 401);
        }

        $request->validate([
            'institution_id' => 'required',
            'heads' => 'required|array|min:1',
            'heads.*.from_head' => 'required|string',
            'heads.*.to_head' => 'required|string',
            'heads.*.amount' => 'required|numeric|min:0.01',
            'heads.*.description' => 'nullable|string',
        ]);

        try {
            $institutionId = $request->institution_id;
            
            $institute = Institute::where('hr_id', $institutionId)->first();
            if (!$institute) {
                return response()->json(['error' => 'Institute not found'], 404);
            }

            $regionalOffice = Institute::where('region_id', $institute->region_id)
                                       ->where('type', 'Regional Office')
                                       ->first();
            if (!$regionalOffice) {
                return response()->json(['error' => 'Regional Office not found for this institute'], 404);
            }

            $user = User::where('inst_id', $institutionId)->first();
            $userId = $user ? $user->id : null;
            $date = Carbon::now()->format('Y-m-d');

            DB::transaction(function () use ($request, $institute, $regionalOffice, $userId, $date) {
                foreach ($request->heads as $headData) {
                    $fromHead = FundHead::where('name', $headData['from_head'])->first();
                    if (!$fromHead) {
                        throw new \Exception("From Fund head '{$headData['from_head']}' not found.");
                    }

                    $toHead = FundHead::where('name', $headData['to_head'])->first();
                    if (!$toHead) {
                        throw new \Exception("To Fund head '{$headData['to_head']}' not found.");
                    }

                    $outBalance = $this->updateAndGetFundBalance($institute->id, $fromHead->id, -$headData['amount'], $userId);
                    $inBalance = $this->updateAndGetFundBalance($regionalOffice->id, $toHead->id, $headData['amount'], $userId);

                    // 1. OUT transaction for base institute
                    Fund::create([
                        'fund_head_id' => $fromHead->id,
                        'description'  => $headData['description'] ?? 'Transfer to Regional ' . $toHead->name,
                        'amount'       => $headData['amount'],
                        'type'         => 'out',
                        'added_date'   => $date,
                        'status'       => 'Approved',
                        'approved_date'=> now(),
                        'approve_by'   => $userId,
                        'added_by'     => $userId,
                        'institute_id' => $institute->id,
                        'tid'          => $regionalOffice->id,
                        'trans_type'   => 'transfer',
                        'balance'      => $outBalance,
                    ]);

                    // 2. IN transaction for regional office
                    Fund::create([
                        'fund_head_id' => $toHead->id,
                        'description'  => $headData['description'] ?? 'Transfer from ' . $fromHead->name . 'Inst:'. $institute->name,
                        'amount'       => $headData['amount'],
                        'type'         => 'in',
                        'added_date'   => $date,
                        'status'       => 'Approved',
                        'approved_date'=> now(),
                        'approve_by'   => $userId,
                        'added_by'     => $userId,
                        'institute_id' => $regionalOffice->id,
                        'tid'          => $institute->id,
                        'trans_type'   => 'transfer',
                        'balance'      => $inBalance,
                    ]);
                }
            });

            return response()->json(['message' => 'Funds transferred successfully'], 200);

        } catch (\Exception $e) {
            Log::error('API transferToRegion error: ' . $e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    private function updateAndGetFundBalance($instituteId, $fundHeadId, $amountChange, $userId)
    {
        $fundHeld = FundHeld::firstWhere([
            'institute_id' => $instituteId,
            'fund_head_id' => $fundHeadId
        ]);

        if ($fundHeld) {
            $newBalance = $fundHeld->balance + $amountChange;
            $fundHeld->update(['balance' => $newBalance]);
            return $newBalance;
        } else {
            FundHeld::create([
                'institute_id' => $instituteId,
                'fund_head_id' => $fundHeadId,
                'balance'      => $amountChange,
                'added_by'     => $userId,
            ]);
            return $amountChange;
        }
    }
}
